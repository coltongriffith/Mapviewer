# Mapviewer

A browser-based GIS map viewer for importing, styling, and annotating geospatial data. Export to PNG or SVG.

## Features

- Import `.zip` (Shapefile), `.geojson`, `.json`, `.csv` layers
- Style layers: stroke, fill, opacity, fill patterns, marker types
- Draw shapes: circle, rectangle, polygon, line
- Annotations: text boxes, callout boxes, curved labels
- Draggable legend, title, logo, inset map, north arrow
- Image overlay (georeferenced raster)
- Export: PNG (full map) or SVG (vector layers)

## Stack

- React 18 + Vite
- Leaflet + shpjs
- No backend — fully client-side

## Setup

```bash
npm install
npm run dev
```

## Build & Preview

```bash
npm run build
npm run preview
```

## Deploy to Vercel

Push to GitHub, import repo on [vercel.com](https://vercel.com). No env vars required.
